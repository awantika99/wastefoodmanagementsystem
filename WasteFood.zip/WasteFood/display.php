
<!Doctype html>
<html>
<head>
<title></title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/table.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/
  css?family=Josefin+Sans&display=swap"
  rel="stylesheet">
</head>
<body>
<?php include  'menu.php' ; ?>
<body>
    <div class="main-div">
        <h1>LIST OF DONOR</h1>
        <div class="center-div">
            <div class="table-responsive">
                <table id="customers">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>donor</th>
                            <th>email</th>
                            <th>mobile</th>
                            <th>mark</th>
                            <th> Food quality</th>
                            <th> Food quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                     include 'connection.php';
                     $selectquery = "select * from donor ";
                     
                     $query = mysqli_query($con,$selectquery);
                     
                     $nums = mysqli_num_rows($query);
                     
                     while($res = mysqli_fetch_array($query))
                      {
                         ?>
                          <tr>
                            <td><?php echo $res['id'];?></td>
                            <td><?php echo $res['donor'];?></td>
                            <td><?php echo $res['email'];?></td>
                            <td><?php echo $res['mobile'];?></td>
                            <td><?php echo $res['mark'];?></td>
                            <td><?php echo $res['quality'];?></td>
                            <td><?php echo $res['quantity'];?></td>
                        </tr>
                        <?php
                           }
                        ?>
                        
                    </tbody>
                </table>
            </div>
        </div>

</div>
</body>
</html>
