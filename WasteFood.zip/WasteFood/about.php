<!Doctype html>
<html>
<head>
<title></title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/about.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/
  css?family=Josefin+Sans&display=swap"
  rel="stylesheet">
</head>
<body>
   <?php include  'menu.php' ; ?>
   <div class="about-section">
  <h1>About Us </h1>
  <p>DESIGN AND IMPLEMENTATION OF WASTE FOOD MANAGEMENT SYSTEM</p>
  <p>Food loss and waste occur at each stage of the global food value chain, from agricultural production to final consumption. 
      Food production is linked to land conversion and biodiversity loss, energy consumption and greenhouse gas emissions, water and pesticide use.
       At the post-harvest and processing stages, there is also waste in each step of the transport, storage, processing and distribution stages.</p>
</p>
<p>This project is used to manage waste foods in a useful way. Everyday the people are wasting lots of foods. So we have to reduce that food waste problem through online. If anyone have leftover foods they are entering their foodquantity details and their address in this web-based application , clicking in button donate which is in our services page and then the admin maintainthe details of food donator.</p>
  
</div>

<div class="row">
  <div class="column">
    <div class="card">
      <img src="images/as1.jpg" alt="Jane" style="width:100%">
      <div class="container">
        
        <p class="title">Discover Our Actions</p>
        <p>Unite For A Hunger Free world.</p>
        <p>awantika@example.com</p>
        <a href="contact.php" class="btn btn-success">Contact Us</a>
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="images/sas8.jpg" alt="Mike" style="width:100%">
      <div class="container">
        
        <p class="title">Discover Our Actions</p>
        <p>Act Sustainbly For Hunger Free World.</p>
        <p>sanjana@example.com</p>
        <a href="checkmore.php" class="btn btn-success">Check More</a>
      </div>
    </div>
  </div>
  <div class="column">
    <div class="card">
      <img src="images/awa4.jpg" alt="John" style="width:100%">
      <div class="container">
        <p class="title">Discover Our Actions </p>
        <p>Food is symbolic of love when words are inadequate.</p>
        <p>ranabir@example.com</p>
        <a href="learn.php" class="btn btn-success">Learn More</a>
      </div>
    </div>
  </div>
</div>
<br>
<br>
<br>
<footer>
    <p class="p-3 bg-dark text-white text-center" >@DESIGN AND IMPLEMENTATION OF WASTE FOOD MANAGEMENT SYSTEM</p>
</footer>
</body>
</html>