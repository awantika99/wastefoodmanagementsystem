<!Doctype html>
<html>
<head>
<title></title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/
  css?family=Josefin+Sans&display=swap"
  rel="stylesheet">
</head>
<body>
   <?php include  'menu.php' ; ?>

<div id="demo" class="carousel slide" data-ride="carousel">
  <ul class="carousel-indicators">
    <li data-target="#demo" data-slide-to="0" class="active"></li>
    <li data-target="#demo" data-slide-to="1"></li>
    <li data-target="#demo" data-slide-to="2"></li>
  </ul>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/sas9.jpg" alt="India" width="1100" height="500">
      <div class="carousel-caption">
        <h3>India</h3>
        <p>We waste 7.6 million tonnes of food each year, 70% of this is perfectly edible. ...!</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="images/awa.jpg" alt="Restaurant" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Restaurant</h3>
        <p>Restaurant owners and managers can employ several strategies to help reduce waste and boost the bottom line!</p>
      </div>   
    </div>
    <div class="carousel-item">
      <img src="images/awa1.jpg" alt="Zero Waste" width="1100" height="500">
      <div class="carousel-caption">
        <h3>Zero Waste</h3>
        <p>Use less of — or do without — unnecessary ingredients. Cook smaller portions to avoid excessive leftovers.!</p>
      </div>   
    </div>
  </div>
  <a class="carousel-control-prev" href="#demo" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#demo" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
</div>
<section class="my-5">
    <div class="py-5 ">
        <h2 class="text-center">OUR AXIOM</h2>
        <br>
        <h3 class="text-center"><p>You have two hands.One to help yourself,the second to help others.</p>
        </h3>
</div>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-4 col-md-4 col-12">
         <img src="images/sas5.jpg" class="img-fluid pb-3">   
        </div>
        <div class="col-lg-4 col-md-4 col-12">
         <img src="images/s2.jpg" class="img-fluid pb-3">   
         <h1>The Act Of Giving Will Transform You.</h1>
        </div>
        <div class="col-lg-4 col-md-4 col-12">
         <img src="images/sas7.jpg" class="img-fluid pb-3">   
        </div>

</div>
</div>
</section>



<footer>
    <p class="p-3 bg-dark text-white text-center" >@DESIGN AND IMPLEMENTATION OF WASTE FOOD MANAGEMENT SYSTEM</p>
</footer>


<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
