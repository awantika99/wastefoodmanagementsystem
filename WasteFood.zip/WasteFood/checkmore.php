<!Doctype html>
<html>
<head>
<title> </title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/
  css?family=Josefin+Sans&display=swap"
  rel="stylesheet">
</head>
<body>
   <?php include 'menu.php' ; ?>
   <div class="jumbotron">
  <h2>INTRODUCTION</h2>
  <p>Food waste is  known as uneaten food or food medication remainders from places or marketable establishments. Everyday billions 
     of tonnes of food including dairy products and vegetables, fruits go on destruction due to the living style of humans and their
      need.According to a report quantum of food waste has been projected to increase in forthcoming times due to growth of population.</p>
  <p>“Food waste” pertains to the eatable and unpalatable factors of food out from the organic phenomenon. which need to be managed through employment or disposal.
      Food waste may also be understood because the loss of eatable food at fully different stages of the organic phenomenon. including product, processing, distribution, and consumption.
      Ineludibly food waste terminated or spoiled ingredients, food scraps like meat scraps. (e.g., finish particulars of baked ham when slicing, meat particulars when trimming) and vegetable.
       scraps (e.g., tomato ends, external leaves of lettuce, potato peels, vegetable stems); and. The left over food at restaurants parties and even at home.  </p>
   <p>Avertible food waste mess scraps like shelling or trimming waste arising from the less practiced handling of food particulars; overrun for feasts, events and. catering; poor ordering procedures; poor food rotation practices, inflicting food. corruption; and poor force systems, performing in food and plate waste like. Also according to a research during the six months 14.74 kilograms of food in total
     Was wasted in a restaurant, the amount of food waste is linked to the total number of consumers during that time period.Monday was recorded as the lowest consumer loads during the whole period under the analysis.The highest consumer record was in December may be due to seasonal changeAcademics categorizes food waste on the base of the stages of waste generation, similar as pre-and post-consumer food waste. Pre-consumer waste occurs at the product position, and post-consumption waste occurs at the consumer position. 
    Consequently, colourful mitigation approaches can reduce similar waste. Likewise, thorough judgments of food waste generated at colourful stages are pivotal for icing the effective operation of waste. Food waste is an important concern because it threatens the terrain and sustainability. In fact, it's a serious concern in the hospitality and tourism sphere. Near to1.3 billion tonnes of eatable food is wasted annually, leading to severe. financial, environmental and health issues.
</p>
</div>

<div class="jumbotron">
<h2>FOOD SYSTEM</h2>
<p>The term food system describes the interconnected systems and processes that influence nutrition, food, health, community development and agriculture. A food system includes all processes and infrastructure involved in feeding  a population: growing, harvesting, processing, packaging, transporting, marketing, 
   consumption, distribution and disposal of food and food-related items.It also includes the inputs needed and outputs generated at each of these steps.Food systems fall within agrifood systems, which encompass the entire range of actors and their interlinked value-adding activities in the primary production 
   of food and non-food agricultural products, as well as in food storage,aggregation, post-harvest handling, transportation, processing, distribution, marketing, disposal and consumption. A food system operates within and is influenced by social, political, economic, and environmental contexts.
  It also requires human resources that provide labor, research and education.Food systems are either conventional or alternative according to their model of food lifespan from origin to plate.</p>
</div>
<div class="jumbotron">
<h2>LOCAL FOOD SYSTEM</h2>
  <p>Local food systems are networks of food production and consumption that aim to be geographically and economically accessible and direct. They contrast to industrial food systems by operating with reduced food transportation and more direct marketing, leading to fewer people between the farmer and the consumer.
     As a result, relationships that are developed in local food systems emerge from face-to-face interactions, potentially leading to a stronger sense of trust and social connectedness between actors. In addition to this, consumers can also encourage farmers to be environmentally friendly by teaching them about 
     practices such as organic farming. As a result, some scholars suggest that local food systems are a good way to revitalize a community.The decreased distance of food transportation has also been promoted for its environmental benefits. Also, farmers can enjoy a better quality of life because producing
      healthier food will allow them to be paid more, and not live under the poverty line.</p>
</div>
<div class="jumbotron">
    <h2>ORGANIC FOOD SYSTEM</h2>
    <p>Organic food systems are characterized by a reduced dependence on chemical inputs and an increased concern for transparency and information. Organic produce is grown without the chemical pesticides and fertilizers of industrial food systems, and livestock is reared without the use of antibiotics or growth hormones.
     The reduced inputs of organic agriculture can also lead to a greater reliance on local knowledge, creating a stronger knowledge community amongst farmers.The transparency of food information is vital for organic food systems as a means through which consumers are able to identify organic food. As a result, a variety 
     of certification bodies have emerged in organic food systems that set the standards for organic identification. Organic agriculture is promoted for the ecological benefits of reduced chemical application, the health benefits of lower chemical consumption, the economic benefits that accrue to farmers through a 
     price premium, and the social benefits of increased transparency in the food system.</P>
</div>

<div class="jumbotron">
    <h2>WASTE FOOD MANAGEMENT SOLUTIONS</h2>
    <br>
    <p><h3>Recycle by Composting:</h3> Food producers can solve 100% of their food waste problems by simply organizing an effective composting strategy. And doing so not only eliminates waste, it also saves you money 
       because you don’t need to “outsource” your compost production.</P>
    <p><h3>Turn Wasted Food into Animal Feed:</h3> Cultivating compost is one way to recycle food, but it can also be done in the bellies of cattle, sheep, pigs, and other livestock (themselves destined to become food).</p>
    <p><h3>Use Waste Food to Produce Products:</h3> From bio-fuels to liquid fertilizer, there are many useful products that can be manufactured from certain kinds of waste foods. And often “left overs” of one company
       could be useful in another industry for the food scrap.</p>
    <p><h3>Source Reduction:</h3>The simplest way to curtail food waste is to simply produce less whenever overproduction is clearly leading to waste.</p>
    <p><h3>Food Donation:</h3> When excess foodstuffs are still safe to eat, they can be given to the hungry and the poor who find it difficult to afford 
       sufficient food in today’s high-priced economy.</p>
</div>
<footer>
    <p class="p-3 bg-dark text-white text-center" >@DESIGN AND IMPLEMENTATION OF WASTE FOOD MANAGEMENT SYSTEM</p>
</footer>
</body>
    </html>