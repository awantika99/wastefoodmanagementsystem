<!Doctype html>
<html>
<head>
<title></title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/contact.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/
  css?family=Josefin+Sans&display=swap"
  rel="stylesheet">
</head>

<body>
<?php include  'menu.php' ; ?>

 <div class="container">
    <div class="content">
      <div class="left-side">
        <div class="address details">
          <i class="fas fa-map-marker-alt"></i>
          <div class="topic">Address</div>
          <div class="text-one">Duhabi 06</div>
          <div class="text-two">Nepal</div>
        </div>
        <div class="phone details">
          <i class="fas fa-phone-alt"></i>
          <div class="topic">Phone</div>
          <div class="text-one">+0098 9893 5647</div>
          <div class="text-two">+0096 3434 5678</div>
        </div>
        <div class="email details">
          <i class="fas fa-envelope"></i>
          <div class="topic">Email</div>
          <div class="text-one">awantika@gmail.com</div>
          <div class="text-two">awantika@gmail.com</div>
        </div>
      </div>
      <div class="right-side">
        <div class="topic-text">Send us a message</div>
        <p>If you want to be a part our journey, you can send us message from here,And be a reason of someone's smile.</P> 
        <form action="#" method="POST">
        <div class="input-box">
          <input type="text" placeholder="Enter your name" name="user" />
        </div>
        <div class="input-box">
          <input type="text" placeholder="Enter your email" name="email" />
        </div>
        <div>
          <input type="submit"  class="btn btn-success" name="submit" value="Send Now"/>
        </div>
      </form>
    </div>
    </div>
  </div>
  <br>
  <br>
  <?php include  'connection.php';

if(isset($_POST['submit'])){

  $user = $_POST['user'];
  $email = $_POST['email'];

  $insertquery = "INSERT INTO contact(user,email) VALUES('$user','$email')";

   $res = mysqli_query($con,$insertquery);
   if($res){
   ?>
   <script>
   alert ("data inserted properly");
   </script>
   <?php
 }
 else
 {
  ?>
  <script>
  alert ("data not inserted ");
  </script>
  <?php

}
}
?>
  
  <footer>
    <p class="p-3 bg-dark text-white text-center" >@DESIGN AND IMPLEMENTATION OF WASTE FOOD MANAGEMENT SYSTEM</p>
</footer>
</body>
</html>



  
