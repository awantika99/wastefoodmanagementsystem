<!Doctype html>
<html>
<head>
<title></title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/login.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/
  css?family=Josefin+Sans&display=swap"
  rel="stylesheet">
</head>
<body>
<div class="wrapper">
      <div class="title">Admin</div>
      <form method="POST" action="display.php">
        <div class="field">
          <input type="text" name ="email" required>
          <label>Email Address</label>
        </div>
        <div class="field">
          <input type="password" name ="psw" required>
          <label>Password</label>
        </div>
        <div class="content">
          <div class="checkbox">
          <input type="checkbox" id="remember-me">
            <label for="remember-me">Remember me</label>
          </div>
          <div>
        <button type="submit"  class="btn btn-primary btn-lg" name="submit">login</button>
        
        <a href="ngo.php" class="btn btn-link">Details</a>
        
      </form>
    </div>
    <br>
<br>
<?php include  'connection.php';

if(isset($_POST['submit'])){

 
  $email = $_POST['email'];
  $psw = $_POST['psw'];

  $psw = password_hash($psw,PASSWORD_BCRYPT);
  
  $insertquery = "INSERT INTO login(email,psw) VALUES('$email','$psw')";

   $res = mysqli_query($con,$insertquery);
   if($res){
   ?>
   <script>
   alert ("Logged in succesfully");
   </script>
   <?php
 }
 else
 {
  ?>
  <script>
  alert ("Login Failed");
  </script>
  <?php

}
}
?>
</body>
</html>