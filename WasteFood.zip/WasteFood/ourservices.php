<!Doctype html>
<html>
<head>
<title></title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/about.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/
  css?family=Josefin+Sans&display=swap"
  rel="stylesheet">
</head>
<body>
    <?php include 'menu.php' ; ?>
    <div class="about-section">
  <h1>Our Service</h1>
  <p>DESIGN AND IMPLEMENTATION OF WASTE FOOD MANAGEMENT SYSTEM</p>
  <p>Globally, nearly one third of food produced for human consumption is lost or wasted, equalling a total of 1.3. billion tonnes of food per year . As the production of food is resource-intensive, 
      food losses and wastes are indirectly accompanied by a broad range of environmental impacts, such as soil erosion, deforestation, water and air pollution, as well as greenhouse gas emissions that occurin the processes of food production, storage, transportation, and waste management.</p>
   <p>Generally, consumers consider throwing away food as improper behaviour , and although consumers state that they do not generate  food waste, or at least less than others , the vast majority of households indicate that they are at least somewhat concerned about throwing away food. Concern about food waste is a significant predictor of food waste reduction and plays an important role in the intention to reduce food waste. People that voice a high environmental concern have a marked aversion towards wasting food. This is reflected in statements that it is ‘wrong or bad’ to waste food. Some consumers also associate food waste with emotions of ‘disgust’, ‘hate’ , ‘frustration’ or ‘annoyance’  and ‘anxiety’.</p>    
 </div>
 <div class="row">
  <div class="column">
    <div class="card">
      <img src="images/aaa.jpg"  style="width:100%">
      <div class="container">
        <p class="title">Donate Surplus Food</p>
        <p>Unite For A Hunger Free world.</p>
        <a href="donate.php" class="btn btn-success">Donate</a>
       </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="images/aa6.jpg"  style="width:100%">
      <div class="container">
      <p class="title">Donate Surplus Food</p>
        <p>Unite For A Hunger Free world.</p>
        <a href="admin.php" class="btn btn-success">Admin</a>
        
      </div>
    </div>
  </div>

  <div class="column">
    <div class="card">
      <img src="images/aa3.jpg"  style="width:100%">
      <div class="container">
      <p class="title">Donate Surplus Food</p>
        <p>Unite For A Hunger Free world.</p>
        <a href="" class="btn btn-success">Agent</a>
      </div>
    </div>
  </div>
  </div>
  <br>
  <br>

<footer>
    <p class="p-3 bg-dark text-white text-center" >@DESIGN AND IMPLEMENTATION OF WASTE FOOD MANAGEMENT SYSTEM</p>
</footer>

</body>
    </html>