<!Doctype html>
<html>
<head>
<title></title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/register.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/
  css?family=Josefin+Sans&display=swap"
  rel="stylesheet">
</head>
<body>
   <?php include  'menu.php' ; ?>
   
   <div class="container">
    <div class="title">Associate With Us.</div>
    <div class="content">
      <form action="#" method="POST">
        <div class="user-details">
          <div class="input-box">
            <span class="details">Username</span>
            <input type="text" placeholder="Enter your username" name="username" required>
            
          </div>
          <div class="input-box">
            <span class="details">Email</span>
            <input type="text" placeholder="Enter your email" name="email" required>
          </div>
          <div class="input-box">
            <span class="details">Phone Number</span>
            <input type="text" placeholder="Enter your number" name="phone" required>
          </div>
          <div class="input-box">
            <span class="details">Password</span>
            <input type="text" placeholder="Enter your password"  name="psw" required>
          </div>
          <div class="input-box">
            <span class="details">Confirm Password</span>
            <input type="text" placeholder="Confirm your password" name="copassword" required>
          </div>
        </div>
        <div class="gender-details">
          <input type="radio" name="gender" id="dot-1">
          <input type="radio" name="gender" id="dot-2">
          <input type="radio" name="gender" id="dot-3">
          <span class="gender-title">Gender</span>
          <div class="category">
            <label for="dot-1">
            <span class="dot one"></span>
            <span class="gender">Male</span>
          </label>
          <label for="dot-2">
            <span class="dot two"></span>
            <span class="gender">Female</span>
          </label>
          <label for="dot-3">
            <span class="dot three"></span>
            <span class="gender">Prefer not to say</span>
            </label>
          </div>
        </div>
        <div>
          <input type="submit"  class="btn btn-success" name="submit" value="Sign up"/>
       </div>
      </form>
    </div>
  </div>
<br>
<br>

<?php include  'connection.php';

if(isset($_POST['submit'])){

  $username = $_POST['username'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $psw = $_POST['psw'];
  $copassword = $_POST['copassword'];

  $psw = password_hash($psw,PASSWORD_BCRYPT);
  $copassword = password_hash($copassword,PASSWORD_BCRYPT);

  $emailquery = " select * from register where email='$email' ";
   $query = mysqli_query($con,$emailquery);

   $emailcount = mysqli_num_rows($query);

   if($emailcount>0){
    ?>
    <script>
        alert("email already exist.");
    </script>

    <?php
    }else
    {$insertquery = "INSERT INTO register(username,email,phone,psw,copassword) VALUES('$username','$email','$phone','$psw','$copassword')";

   $res = mysqli_query($con,$insertquery);
   if($res){
   ?>
   <script>
   alert ("data inserted");
   </script>
   <?php
 }
 else
 {
  ?>
  <script>
  alert ("data not inserted ");
  </script>
  <?php

 }
}
}
?>
<footer>
    <p class="p-3 bg-dark text-white text-center" >@DESIGN AND IMPLEMENTATION OF WASTE FOOD MANAGEMENT SYSTEM</p>
</footer>
</body>
</html>