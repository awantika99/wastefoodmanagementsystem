<!Doctype html>
<html>
<head>
<title></title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/register.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/
  css?family=Josefin+Sans&display=swap"
  rel="stylesheet">
</head>
<body>
   <?php include  'menu.php' ; ?>
   <div class="container">
    <div class="title">In-Kind Donations</div>
    <div class="content">
      <form action="#" method="POST">
        <div class="user-details">
          <div class="input-box">
            <span class="details">Donorname</span>
            <input type="text" placeholder="Enter your name"  name="donor" required>
          </div>
          <div class="input-box">
            <span class="details">Email</span>
            <input type="text" placeholder="Enter your email" name="email" required>
          </div>
          <div class="input-box">
          <span class="details">Phone Number</span>
            <input type="text" placeholder="Enter your number" name="mobile" required>
          </div>
          <div class="input-box">
            <span class="details">Address</span>
            <input type="text" placeholder="Enter your address"  name="mark" required>
          </div>
          <div class="input-box">
            <span class="details">Food quality</span>
            <input type="text" placeholder="Confirm your quality" name="quality" required>
          </div>
          <div class="input-box">
            <span class="details">Food quantity</span>
            <input type="text" placeholder="Confirm your quantity"  name="quantity"required>
          </div>
        </div>
         <div class="button">
           <input type="submit"  class="btn btn-success" name="submit" value="Donate"/>
         
        </div>
      </form>
    </div>
  </div>
<br>
<br>
<?php include  'connection.php';

if(isset($_POST['submit'])){

  $donor = $_POST['donor'];
  $email = $_POST['email'];
  $mobile = $_POST['mobile'];
  $mark = $_POST['mark'];
  $quality = $_POST['quality'];
  $quantity = $_POST['quantity'];

  $insertquery = "INSERT INTO donor(donor,email,mobile,mark,quality,quantity) 
  VALUES('$donor','$email','$mobile','$mark','$quality','$quantity')";

   $res = mysqli_query($con,$insertquery);
   if($res){
   ?>
   <script>
   alert ("Details Placed");
   </script>
   <?php
   }
   else
   {
    ?>
    <script>
    alert ("Details not Placed");
    </script>
    <?php
  
   }
  }
  ?>


<footer>
    <p class="p-3 bg-dark text-white text-center" >@DESIGN AND IMPLEMENTATION OF WASTE FOOD MANAGEMENT SYSTEM</p>
</footer>
</body>
</html>