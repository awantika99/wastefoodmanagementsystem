<!Doctype html>
<html>
<head>
<title> </title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/
  css?family=Josefin+Sans&display=swap"
  rel="stylesheet">
</head>
<body>
   <?php include 'menu.php' ; ?>
   <div class="container">
   <h2>Mission Possible to End World Hunger.</h2>
  <br>
  <div class="card bg-primary text-white">
    <div class="card-body"><h4>Respect Food</h4></div>
    <p>Food connects us all. Re-connect with food by knowing the process that goes into making it.
       Read about food production and get to know your farmers.</P>
  </div>
  <br>
  <div class="card bg-success text-white">
    <div class="card-body"><h4>Store Food Wisely</h4></div>
    <p>Move older products to the front of your cupboard or fridge and new ones to the back. 
      Use airtight containers to keep open food fresh in the fridge and ensure packets are closed to stop insects from getting in.</p>
  </div>
  <br>
  <div class="card bg-info text-white">
    <div class="card-body"><h4>Adopt A Healthier, More Sustainable Diet</h4></div>
    <p>Life is fast-paced and preparing nutritious meals can be a challenge, but healthy meals don't have to be elaborate.</p>
  </div>
  <br>
  <div class="card bg-warning text-white">
    <div class="card-body"><h4>Buy Only What You Need</h4></div>
    <p>Plan your meals. Make a shopping list and stick to it, and avoid impulse buys.
       Not only will you waste less food, you’ll also save money!</p>
  </div>
  <br>
  <div class="card bg-danger text-white">
    <div class="card-body"><h4>Love Your Leftovers</h4></div>
    <p>If you don’t eat everything you make, freeze it for later or use the leftovers as an ingredient in another meal.</p>
  </div>
  <br>
  <div class="card bg-secondary text-white">
    <div class="card-body"><h4>Start Small</h4></div>
    <p>Take smaller portions at home or share large dishes at restaurants.</p>
  </div>
  <br>
  <div class="card bg-danger text-white">
    <div class="card-body"><h4>Love Your Leftovers</h4></div>
    <p>If you don’t eat everything you make, freeze it for later or use the leftovers as an ingredient in another meal.</p>
  </div>
  <br>
  <div class="card bg-secondary text-white">
    <div class="card-body"><h4>Love Your Food</h4></div>
    <p>Donating to the needy is a great way to improve the conditions in your neighborhood or community. Donating food to the worthy people or organizations helps counter poverty, hunger and at the same time, it can improve harmony, friendliness, and trust among residents.</p>
  </div>
  <br>
  <div class="card bg-success text-white">
    <div class="card-body"><h4>Donation</h4></div>
    <p>The measure of a life, after all, is not its duration, but its donation.</p>
  </div>
  <br>
  <div class="card bg-info text-white">
    <div class="card-body"><h4>In-Kind Contribution</h4></div>
    <p>Making a donation is the ultimate sign of solidarity. Actions speak louder than words.</p>
  </div>
  <br>
  <div class="card bg-warning text-white">
    <div class="card-body"><h4>Give a Smile </h4></div>
    <p> “Providing better health by curing hunger.”.</p>
  </div>
  <br>
  </div>
<footer>
    <p class="p-3 bg-dark text-white text-center" >@DESIGN AND IMPLEMENTATION OF WASTE FOOD MANAGEMENT SYSTEM</p>
</footer>
</body>
    </html>