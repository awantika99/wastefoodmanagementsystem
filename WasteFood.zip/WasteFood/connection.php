<?php

$username = "root";
$password = '';
$server = 'localhost';
$db = 'wastefood';



$con = mysqli_connect($server,$username,$password,$db);

if($con)
{
    //echo "connection successfull";
    ?>
    <script>
        alert ('connection successful')
    </script>
    <?php

}else
{
    //echo "No connection";
    ?>
    <script>
        alert (' No connection ')
    </script>
    <?php

}

?>