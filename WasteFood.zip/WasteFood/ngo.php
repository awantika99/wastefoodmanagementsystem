<!Doctype html>
<html>
<head>
<title></title>
<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="css/ngo.css">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <link href="https://fonts.googleapis.com/
  css?family=Josefin+Sans&display=swap"
  rel="stylesheet">
</head>
<body>
<?php include  'menu.php' ; ?>
<body>  
<h1> AVALIABLE NGO LIST </h1>  
<div class="container">  
  <div class="row">  
    <div class="col-12">  
        <table class="table table-image">  
          <thead>  
            <tr>  
              <th scope="col">S.No</th>  
              <th scope="col"> NGO Name </th>  
              <th scope="col"> Address </th>  
              <th scope="col"> Founder </th>  
              <th scope="col"> Contact </th>  
            </tr>  
          </thead>  
          <tbody>  
            <tr>  
              <th scope="row"> 1 </th>  
              <td> Smile Foundation </td>  
              <td> New Delhi</td>  
              <td> Santanu Mishra </td>  
              <td> +91-22-68251098 </td>  
            </tr>  
            <tr>  
              <th scope="row"> 2 </th>  
              <td> Childline India Foundation </td>  
              <td> Maharashtra </td>  
              <td> 	Jeroo Billimoria </td>  
              <td>+91-22-68251098 </td>  
            </tr>  
            <tr>  
              <th scope="row"> 3 </th>  
              <td> Nanhi Kali </td>  
              <td> Chitwan </td>  
              <td> 	Anand Mahindra </td>  
              <td>+977-22-68251098 </td>  
            </tr> 
            <tr>  
              <th scope="row"> 4 </th>  
              <td> KOPILA Nepal  </td>  
              <td> Pokhara </td>  
              <td> 	Prakash Wagle </td>  
              <td>+977-22-68251098 </td>  
            </tr> 
            <tr>  
              <th scope="row"> 5 </th>  
              <td> BAL KALYAN</td>  
              <td> Duhabi </td>  
              <td> Ram Chaudhary </td>  
              <td>+977-22-68251098 </td>  
            </tr> 
            <tr>  
              <th scope="row"> 6 </th>  
              <td> NATURE Nepal  </td>  
              <td> Jawagal  </td>  
              <td> 	Arvind Sah </td>  
              <td>+977-22-68251098 </td>  
            </tr> 
            <tr>  
              <th scope="row"> 7 </th>  
              <td> SAVING LIVES </td>  
              <td> Maharashtra </td>  
              <td> Pavinder Singh </td>  
              <td>+91 11 4655 4000 </td>  
            </tr> 
            <tr>  
              <th scope="row"> 8 </th>  
              <td> GiveIndia </td>  
              <td> Bengaluru </td>  
              <td> 	Venkat Krishnan </td>  
              <td>+91-22-68251098 </td>  
            </tr> 
            <tr>  
              <th scope="row"> 9 </th>  
              <td> GiveNepal </td>  
              <td> Itahari </td>  
              <td> Krishnan Pandey </td>  
              <td>+977-22-68251098 </td>  
            </tr> 
            <tr>  
              <th scope="row"> 10 </th>  
              <td> Give Smile </td>  
              <td> Kathmandu </td>  
              <td> Aastha Chaudhary </td>  
              <td>+977-22-68251098 </td>  
            </tr> 
          </tbody>  
        </table>     
    </div>      
  </div>  
</div>  
<br>
<br>
<br>
<footer>
    <p class="p-3 bg-dark text-white text-center" >@DESIGN AND IMPLEMENTATION OF WASTE FOOD MANAGEMENT SYSTEM</p>
</footer>
</body>  
</html>  




